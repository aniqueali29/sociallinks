<?php
// google-config.php - Configuration for Google OAuth 2.0 authentication

// Google OAuth 2.0 Client credentials
// Replace these with your actual Google OAuth API credentials from Google Developer Console
$googleClientId = "951086372530-s3d7av633jc912mkcvjgd30osb7ij7j0.apps.googleusercontent.com";
$googleClientSecret = "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";

// $googleLoginRedirectUrl = 'https://sociallinks.datasaver.online/login.php';
// $googleRegisterRedirectUrl = 'https://sociallinks.datasaver.online/register.php';

$googleLoginRedirectUrl = 'http://localhost/mini/login.php';
$googleRegisterRedirectUrl = 'http://localhost/mini/register.php';


// Google API configuration
$googleAPIScope = [
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
];

// OAuth endpoints - these generally don't need to be changed
$googleOAuthUri = 'https://accounts.google.com/o/oauth2/auth';
$googleTokenUri = 'https://oauth2.googleapis.com/token';
$googleInfoUri = 'https://www.googleapis.com/oauth2/v3/userinfo';

// Error handling
$googleAuthError = isset($_GET['error']) ? $_GET['error'] : null;
if ($googleAuthError) {
    error_log("Google OAuth Error: " . $googleAuthError);
}
?>